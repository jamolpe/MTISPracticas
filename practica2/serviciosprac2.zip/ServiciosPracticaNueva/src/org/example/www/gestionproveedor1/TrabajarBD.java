package org.example.www.gestionproveedor1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class TrabajarBD {
	private static ResultSet resultSet = null;
	private static int resultadoInsert = 0;
	private static Connection connection = null;
	private static Statement statement = null;
	private static PreparedStatement preparedStatement = null;
	
	
	private static ResultSet EjecutarComando(String comando,String basedatos){
		
		ResultSet resultado = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		}catch(Exception e) {
			System.out.println("Unable to load Driver");
			resultado = null;
		}
		
		//Establish connection using DriverManager 
		try {
		 connection = 
	        DriverManager.getConnection("jdbc:mysql://localhost/"+basedatos, "root", "");
		} catch (SQLException e) {
			System.out.println("Unable to connect to database");
			resultado = null;
		}
		
		//if connection is successfully established, create statement
        if(connection != null) {
	    try {
	       statement = connection.createStatement();
	    } catch (SQLException e) {
	       System.out.println("Unable to create statement");
	       resultado = null;
	    }
	    
	}
        //if statement is created successfully, execute query and get results
        if(statement != null) {
	   try {
		   resultado = statement.executeQuery(comando);
	   } catch (SQLException e) {
	        System.out.println("Unable to create statement");
	        resultado = null;
	       
	   }
        }
        
        return resultado;
       
	}
	
	private static int EjecutarComandoInsert(String comando,String basedatos){
		
		
		int resultado = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		}catch(Exception e) {
			System.out.println("Unable to load Driver");
			resultSet = null;
		}
		
		//Establish connection using DriverManager 
		try {
		 connection = 
	        DriverManager.getConnection("jdbc:mysql://localhost/"+basedatos, "root", "");
		} catch (SQLException e) {
			System.out.println("Unable to connect to database");
			resultSet = null;
		}
		
		//if connection is successfully established, create statement
        if(connection != null) {
	    try {
	    	preparedStatement =  connection.prepareStatement(comando);
	    } catch (SQLException e) {
	       System.out.println("Unable to create statement");
	       resultSet = null;
	    }
	    
	}
        //if statement is created successfully, execute query and get results
        if(preparedStatement != null) {
	   try {
		   resultado = preparedStatement.executeUpdate();
	   } catch (SQLException e) {
	        System.out.println("Unable to create statement");
	        resultSet = null;
	       
	   }
        }
        
        return resultado;
        
       
	}
	
	
	static float SolicitarPresupuestoBD(SolicitarPresupuesto presupuesto){
		

		float valor= (float)0.0;
		int numUnidades = presupuesto.localNumeroUnidades;
		String referencia = presupuesto.localReferenciaProducto;
		ResultSet resultado = null;
		
		if(ComprobarStock(presupuesto)){
			String comando = "SELECT Precio FROM piezas WHERE Referencia='"+ referencia+"'";
			String bd= "proveedor1";
			
			resultado = EjecutarComando(comando,bd);
			if(resultado!=null){
				float precioPieza;
				try {
					resultado.next();
					precioPieza = Float.parseFloat(resultado.getString(1));
					valor = precioPieza * numUnidades;
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}else{
				valor= 0;
			}
		}
		
		return valor;
		
	}
	
	
	static boolean  ComprobarStock(SolicitarPresupuesto comprobarStock){
		
		
		boolean comprobado=false;
		int numUnidades = comprobarStock.localNumeroUnidades;
		String referencia = comprobarStock.localReferenciaProducto;
		ResultSet resultado = null;
		
		String comando = "SELECT Unidades FROM Piezas WHERE Referencia='"+ referencia+"'";
		String bd= "proveedor1";
		
		resultado = EjecutarComando(comando,bd);
		
		if(resultado!=null){
			try {
				resultado.next();
				if(Integer.parseInt(resultado.getString(1)) >= numUnidades){
					comprobado=true;
				}
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return comprobado;
	}
	
	
	static boolean OrdenarCompra(OrdenarCompra ordenarCompra){
		
		boolean actualizado=false;
		int numUnidades = ordenarCompra.localNumeroUnidades;
		String referencia = ordenarCompra.localReferenciaProducto;
		ResultSet resultado = null;
		
		String comando = "SELECT Unidades FROM Piezas WHERE Referencia='"+ referencia+"'";
		String bd= "proveedor1";
		
		resultado = EjecutarComando(comando,bd);
		if(resultado!=null){
			int cantidadActual;
			try {
				resultado.next();
				cantidadActual = Integer.parseInt(resultado.getString(1));
				int cantidadNueva = cantidadActual - numUnidades;
				if(cantidadNueva >= 0){
					String comando2 = "Update Piezas set Unidades = " + cantidadNueva + " where Referencia='" + referencia + "';";
					int res =EjecutarComandoInsert(comando2,bd);
					if(res>0){
						actualizado= true;
					}
				}

			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}else{
			actualizado= false;
		}
		return actualizado;
				
	}

}
