
/**
 * GestionProveedor3Skeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
package org.example.www.gestionproveedor3;



/**
 * GestionProveedor3Skeleton java skeleton for the axisService
 */
public class GestionProveedor3Skeleton {

	/**
	 * Auto generated method signature
	 * 
	 * @param solicitarPresupuesto
	 * @return solicitarPresupuestoResponse
	 */

	public org.example.www.gestionproveedor3.SolicitarPresupuestoResponse solicitarPresupuesto(
			org.example.www.gestionproveedor3.SolicitarPresupuesto solicitarPresupuesto) {
		
		SolicitarPresupuestoResponse respuesta = new SolicitarPresupuestoResponse();
		
		respuesta.setRespuesta(TrabajarBD.SolicitarPresupuestoBD(solicitarPresupuesto));
		return respuesta;
	}

	/**
	 * Auto generated method signature
	 * 
	 * @param ordenarCompra
	 * @return ordenarCompraResponse
	 */

	public org.example.www.gestionproveedor3.OrdenarCompraResponse ordenarCompra(
			org.example.www.gestionproveedor3.OrdenarCompra ordenarCompra) {
		OrdenarCompraResponse respuesta = new OrdenarCompraResponse();
		respuesta.setRespuesta(TrabajarBD.OrdenarCompra(ordenarCompra));
		return respuesta;
	}

}
