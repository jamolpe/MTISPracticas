package org.example.www.gestionalmacen;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class TrabajarBD {
	private static ResultSet resultSet = null;
	private static int resultadoInsert = 0;
	private static Connection connection = null;
	private static Statement statement = null;
	private static PreparedStatement preparedStatement = null;
	
	
	private static ResultSet EjecutarComando(String comando,String basedatos){
		
		ResultSet resultado = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		}catch(Exception e) {
			System.out.println("Unable to load Driver");
			resultado = null;
		}
		
		//Establish connection using DriverManager 
		try {
		 connection = 
	        DriverManager.getConnection("jdbc:mysql://localhost/"+basedatos, "root", "");
		} catch (SQLException e) {
			System.out.println("Unable to connect to database");
			resultado = null;
		}
		
		//if connection is successfully established, create statement
        if(connection != null) {
	    try {
	       statement = connection.createStatement();
	    } catch (SQLException e) {
	       System.out.println("Unable to create statement");
	       resultado = null;
	    }
	    
	}
        //if statement is created successfully, execute query and get results
        if(statement != null) {
	   try {
		   resultado = statement.executeQuery(comando);
	   } catch (SQLException e) {
	        System.out.println("Unable to create statement");
	        resultado = null;
	       
	   }
        }
        
        return resultado;
       
	}
	
	private static int EjecutarComandoInsert(String comando,String basedatos){
		
		
		int resultado = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		}catch(Exception e) {
			System.out.println("Unable to load Driver");
			resultSet = null;
		}
		
		//Establish connection using DriverManager 
		try {
		 connection = 
	        DriverManager.getConnection("jdbc:mysql://localhost/"+basedatos, "root", "");
		} catch (SQLException e) {
			System.out.println("Unable to connect to database");
			resultSet = null;
		}
		
		//if connection is successfully established, create statement
        if(connection != null) {
	    try {
	    	preparedStatement =  connection.prepareStatement(comando);
	    } catch (SQLException e) {
	       System.out.println("Unable to create statement");
	       resultSet = null;
	    }
	    
	}
        //if statement is created successfully, execute query and get results
        if(preparedStatement != null) {
	   try {
		   resultado = preparedStatement.executeUpdate();
	   } catch (SQLException e) {
	        System.out.println("Unable to create statement");
	        resultSet = null;
	       
	   }
        }
        
        return resultado;
        
       
	}
	
	
	static boolean  ActualizarStockBD(ActualizarStock actualizarStock){
		
		boolean actualizado=false;
		int numUnidades = actualizarStock.localNumeroUnidades;
		String referencia = actualizarStock.localReferenciaProducto;
		ResultSet resultado = null;
		
		String comando = "SELECT unidades FROM Piezas WHERE referencia='"+ referencia+"'";
		String bd= "almacen";
		
		resultado = EjecutarComando(comando,bd);
		if(resultado!=null){
			int cantidadActual;
			try {
				resultado.next();
				cantidadActual = Integer.parseInt(resultado.getString(1));
				int cantidadNueva = cantidadActual - numUnidades;
				if(cantidadNueva >= 0){
					String comando2 = "Update Piezas set unidades = " + cantidadNueva + " where referencia='" + referencia + "';";
					int res =EjecutarComandoInsert(comando2,bd);
					if(res>0){
						actualizado= true;
					}
				}

			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}else{
			actualizado= false;
		}
		return actualizado;
		
	}
	
	static boolean  ComprobarStock(ComprobarStock comprobarStock){
		
		
		boolean comprobado=false;
		int numUnidades = comprobarStock.localNumeroUnidades;
		String referencia = comprobarStock.localReferenciaProducto;
		ResultSet resultado = null;
		
		String comando = "SELECT unidades FROM Piezas WHERE referencia='"+ referencia+"'";
		String bd= "almacen";
		
		resultado = EjecutarComando(comando,bd);
		
		if(resultado!=null){
			try {
				resultado.next();
				if(Integer.parseInt(resultado.getString(1)) >= numUnidades){
					comprobado=true;
				}
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return comprobado;
	}

}
