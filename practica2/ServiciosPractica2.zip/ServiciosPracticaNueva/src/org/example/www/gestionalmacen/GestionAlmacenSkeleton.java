
/**
 * GestionAlmacenSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
package org.example.www.gestionalmacen;

/**
 * GestionAlmacenSkeleton java skeleton for the axisService
 */
public class GestionAlmacenSkeleton {

	/**
	 * Auto generated method signature
	 * 
	 * @param comprobarStock
	 * @return comprobarStockResponse
	 */

	public org.example.www.gestionalmacen.ComprobarStockResponse comprobarStock(
			org.example.www.gestionalmacen.ComprobarStock comprobarStock) {
		
		ComprobarStockResponse respuesta = new ComprobarStockResponse();
		
		respuesta.setResultado(TrabajarBD.ComprobarStock(comprobarStock));
		
		return respuesta;
	}

	/**
	 * Auto generated method signature
	 * 
	 * @param actualizarStock
	 * @return actualizarStockResponse
	 */

	public org.example.www.gestionalmacen.ActualizarStockResponse actualizarStock(
			org.example.www.gestionalmacen.ActualizarStock actualizarStock) {
		
		ActualizarStockResponse respuesta = new ActualizarStockResponse();

		respuesta.setResultado(TrabajarBD.ActualizarStockBD(actualizarStock));
		
		return respuesta;
	}

}
